Statement: Lex to count the number of characters, words,
newlines, and white spaces.

Practice
Problem
● To read the source code of lex.yy.c file.
● Make a note of minimum 15 routines
mentioned in lex.yy.c
● Write a line about the working of these
routines in general.
● Count the number of occurrences of IF,
FOR, WHILE loop in lex.yy.c.
